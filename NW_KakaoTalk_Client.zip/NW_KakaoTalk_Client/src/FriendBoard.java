import ImageResizer.ImageResizer;
import User.User;
import Utilization.Util;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;

public class FriendBoard extends JFrame {
    private String user;

    private JPanel FriendPanel;
    private JPanel fieldPanel;
    private JLabel lblField;
    private JButton btnSearch;
    private JButton btnAdd;
    private JScrollPane scrFriend;
    private JPanel container;
    private JTextField txtSearch;

    private Socket socket;
    private Scanner clientInput;
    private PrintWriter clientOutput;

    private ArrayList<User> searched;

    public JPanel getFriendPanel() {
        return this.FriendPanel;
    }

    FriendBoard(String user, Socket socket) {
        this.user = user;
        this.socket = socket;

        try{
            clientInput = new Scanner(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            clientOutput = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
        } catch(Exception e) {
            e.printStackTrace();
        }

        searched = new ArrayList<User>();
        container.setLayout((new GridLayout(1000, 1)));
        scrFriend.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        txtSearch.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String searchJSON = Util.createSingleJSON(3001, "search", txtSearch.getText());
                clientOutput.println(searchJSON);

                if (clientInput.hasNextLine()) {
                    String serverOutput = new String();

                    try {
                        serverOutput = clientInput.nextLine();
                        if (serverOutput.isEmpty()) serverOutput = clientInput.nextLine();

                        JSONParser parser = new JSONParser();
                        JSONObject object = (JSONObject) parser.parse(serverOutput);

                        int response = Integer.parseInt(String.valueOf(object.get("code")));

                        if (response == 200) {
                            String searchResult = String.valueOf(object.get("search"));
                            System.out.println(searchResult);

                            if (searchResult.equals("true")) {
                                container.removeAll();

                                ArrayList<User> searchedUser = (ArrayList<User>) object.get("searched");
                                for (int i = 0; i < searchedUser.size(); i++) {
                                    JLabel lbl = new JLabel();
                                    lbl.setText(searchedUser.get(i).getNickName());
                                    lbl.addMouseListener(new MouseAdapter() {
                                        @Override
                                        public void mouseClicked(MouseEvent e) {

                                        }
                                    });

                                    container.add(lbl);
                                }

                                MainFrame.getTarget().removeAll();
                                MainFrame.getTarget().add(fieldPanel);
                                txtSearch.requestFocus();
                            }
                            else {
                                container.removeAll();

                                MainFrame.getTarget().removeAll();
                                MainFrame.getTarget().add(fieldPanel);
                                txtSearch.requestFocus();
                            }
                        } else {
                            System.out.println("Search Error");
                        }
                    } catch (ParseException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });

        JButton[] btnGroup = new JButton[2];
        btnGroup[0] = btnSearch;
        btnGroup[1] = btnAdd;

        ImageResizer.FriendBoardImage(btnGroup);
    }
}
