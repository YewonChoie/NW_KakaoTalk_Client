package Object;

public class ServerInfo {
    public String serverIP;
    public int serverPort;

    public ServerInfo(String serverIP, int serverPort) {
        this.serverIP = serverIP;
        this.serverPort = serverPort;
    }
}
